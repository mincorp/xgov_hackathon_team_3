sdists should include this (see pyproject.toml)
