Sample description for test.
